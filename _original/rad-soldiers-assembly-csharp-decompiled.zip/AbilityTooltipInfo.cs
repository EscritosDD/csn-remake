﻿// Decompiled with JetBrains decompiler
// Type: AbilityTooltipInfo
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: C4E058C3-52EE-49D9-9B60-4517452EDFF8
// Assembly location: C:\Users\Flo\Desktop\Neuer Ordner (2)\TacticsGame.unity3d_unpacked\Assembly-CSharp.dll

using System;
using 딢;

[Serializable]
public class AbilityTooltipInfo
{
  public 딴 ability;
  public 딮 type;
  public LocalisationEntry headerText;
  public LocalisationEntry messageText;
}
