﻿// Decompiled with JetBrains decompiler
// Type: SplashDamage.Mobile.Fireteam.ErrorData
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: C4E058C3-52EE-49D9-9B60-4517452EDFF8
// Assembly location: C:\Users\Flo\Desktop\Neuer Ordner (2)\TacticsGame.unity3d_unpacked\Assembly-CSharp.dll

using System;

namespace SplashDamage.Mobile.Fireteam
{
  [딧.딷]
  [Serializable]
  public sealed class ErrorData
  {
    [딧.떁(Name = "code")]
    public 딟.땑 Code;
    [딧.떁(Name = "error")]
    public string Error;
    [딧.떁(Name = "message")]
    public string Message;
  }
}
