﻿// Decompiled with JetBrains decompiler
// Type: SplashDamage.Mobile.JavaScript.ExternalCallResponse
// Assembly: Assembly-CSharp, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: C4E058C3-52EE-49D9-9B60-4517452EDFF8
// Assembly location: C:\Users\Flo\Desktop\Neuer Ordner (2)\TacticsGame.unity3d_unpacked\Assembly-CSharp.dll

using System;
using 딧;

namespace SplashDamage.Mobile.JavaScript
{
  [딷]
  [Serializable]
  internal sealed class ExternalCallResponse
  {
    [떁(Name = "id")]
    public string Id;
    [떁(Name = "value")]
    public object Value;
  }
}
